
import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import DriverHeader from './components/DriverHeader';
import DriverSidebar from './components/DriverSidebar';
import DashboardOverview from './components/DashboardOverview';
import AvailableOrders from './components/AvailableOrders';
import MyDeliveries from './components/MyDeliveries';
import DriverProfile from './components/DriverProfile';
import Earnings from './components/Earnings';

export default function DriverDashboardPage() {
  const [currentView, setCurrentView] = useState('overview');
  const [driver, setDriver] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    checkDriver();
  }, []);

  const checkDriver = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        window.REACT_APP_NAVIGATE('/driver-login');
        return;
      }

      const { data: driverData, error } = await supabase
        .from('drivers')
        .select('*')
        .eq('id', user.id)
        .single();

      if (error || !driverData) {
        window.REACT_APP_NAVIGATE('/driver-login');
        return;
      }

      if (driverData.status !== 'approved') {
        window.REACT_APP_NAVIGATE('/driver-login');
        return;
      }

      setDriver(driverData);
      setIsLoading(false);
    } catch (error) {
      console.error('خطأ في التحقق من السائق:', error);
      window.REACT_APP_NAVIGATE('/driver-login');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <DriverHeader driver={driver} />
      
      <div className="flex">
        <DriverSidebar currentView={currentView} setCurrentView={setCurrentView} />
        
        <main className="flex-1 mr-64 mt-16 p-8">
          {currentView === 'overview' && <DashboardOverview driver={driver} />}
          {currentView === 'available-orders' && <AvailableOrders driver={driver} />}
          {currentView === 'my-deliveries' && <MyDeliveries driver={driver} />}
          {currentView === 'earnings' && <Earnings driver={driver} />}
          {currentView === 'profile' && <DriverProfile driver={driver} setDriver={setDriver} />}
        </main>
      </div>
    </div>
  );
}
