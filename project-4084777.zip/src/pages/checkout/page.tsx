import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';
import { supabase } from '../../lib/supabase';

interface CartItem {
  id: string;
  name: string;
  restaurant: string;
  restaurant_id: string;
  price: number;
  quantity: number;
  image: string;
}

interface DeliveryInfo {
  name: string;
  phone: string;
  address: string;
  city: string;
  notes: string;
}

export default function CheckoutPage() {
  const navigate = useNavigate();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [deliveryInfo, setDeliveryInfo] = useState<DeliveryInfo>({
    name: '',
    phone: '',
    address: '',
    city: '',
    notes: ''
  });
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<{[key: string]: string}>({});
  const [appliedPromo, setAppliedPromo] = useState<any>(null);
  const [currentUser, setCurrentUser] = useState<any>(null);

  useEffect(() => {
    checkUser();
    loadCartData();
    loadDeliveryInfo();
    loadAppliedPromo();
  }, []);

  const checkUser = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      setCurrentUser(user);
    } catch (error) {
      console.error('خطأ في التحقق من المستخدم:', error);
    }
  };

  const loadCartData = async () => {
    try {
      setIsLoading(true);
      
      // قراءة السلة من localStorage
      const savedCart = localStorage.getItem('cart');
      if (!savedCart) {
        setCartItems([]);
        setIsLoading(false);
        return;
      }

      const cart = JSON.parse(savedCart);
      const productIds = Object.keys(cart);

      if (productIds.length === 0) {
        setCartItems([]);
        setIsLoading(false);
        return;
      }

      // جلب بيانات المنتجات من قاعدة البيانات
      const { data: products, error } = await supabase
        .from('products')
        .select('*, restaurants(id, name)')
        .in('id', productIds);

      if (error) {
        console.error('خطأ في تحميل المنتجات:', error);
        setCartItems([]);
        setIsLoading(false);
        return;
      }

      // تحويل البيانات لصيغة السلة
      const items: CartItem[] = products.map(product => ({
        id: product.id,
        name: product.name,
        restaurant: product.restaurants?.name || 'مطعم غير معروف',
        restaurant_id: product.restaurant_id,
        price: product.price,
        quantity: cart[product.id],
        image: product.image_url || `https://readdy.ai/api/search-image?query=delicious%20$%7Bproduct.name%7D%20food%20dish%20on%20white%20plate%2C%20professional%20food%20photography%2C%20appetizing%20presentation&width=100&height=100&seq=cart-${product.id}&orientation=squarish`
      }));

      setCartItems(items);
      setIsLoading(false);

    } catch (error) {
      console.error('خطأ في تحميل السلة:', error);
      setCartItems([]);
      setIsLoading(false);
    }
  };

  const loadDeliveryInfo = () => {
    try {
      const savedDeliveryInfo = localStorage.getItem('deliveryInfo');
      if (savedDeliveryInfo) {
        const parsedInfo = JSON.parse(savedDeliveryInfo);
        setDeliveryInfo(parsedInfo);
      }
    } catch (error) {
      console.error('خطأ في تحليل معلومات التوصيل:', error);
    }
  };

  const loadAppliedPromo = () => {
    try {
      const savedPromo = localStorage.getItem('appliedPromo');
      if (savedPromo) {
        setAppliedPromo(JSON.parse(savedPromo));
      }
    } catch (error) {
      console.error('خطأ في تحميل الخصم:', error);
    }
  };

  const validateForm = (): boolean => {
    const newErrors: {[key: string]: string} = {};

    if (!deliveryInfo.name.trim()) {
      newErrors.name = 'الاسم مطلوب';
    } else if (deliveryInfo.name.trim().length < 2) {
      newErrors.name = 'الاسم يجب أن يكون أكثر من حرفين';
    }

    if (!deliveryInfo.phone.trim()) {
      newErrors.phone = 'رقم الهاتف مطلوب';
    } else if (!/^[0-9+\-\s()]{10,15}$/.test(deliveryInfo.phone.trim())) {
      newErrors.phone = 'رقم الهاتف غير صحيح';
    }

    if (!deliveryInfo.address.trim()) {
      newErrors.address = 'العنوان مطلوب';
    } else if (deliveryInfo.address.trim().length < 10) {
      newErrors.address = 'يرجى إدخال عنوان مفصل أكثر';
    }

    if (!deliveryInfo.city) {
      newErrors.city = 'المدينة مطلوبة';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (field: keyof DeliveryInfo, value: string) => {
    setDeliveryInfo(prev => ({
      ...prev,
      [field]: value
    }));

    // إزالة رسالة الخطأ عند التعديل
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }

    // حفظ المعلومات في localStorage
    const updatedInfo = { ...deliveryInfo, [field]: value };
    localStorage.setItem('deliveryInfo', JSON.stringify(updatedInfo));
  };

  const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const deliveryFee = 25;
  const discount = appliedPromo ? 
    (appliedPromo.type === 'percentage' ? subtotal * (appliedPromo.discount / 100) : appliedPromo.discount) : 0;
  const total = subtotal + deliveryFee - discount;

  const generateOrderId = (): string => {
    return 'ORD-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9).toUpperCase();
  };

  const handleSubmitOrder = async () => {
    if (!validateForm()) {
      // التمرير إلى أول خطأ
      const firstErrorField = Object.keys(errors)[0];
      const errorElement = document.querySelector(`[name="${firstErrorField}"]`);
      if (errorElement) {
        errorElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      return;
    }

    if (cartItems.length === 0) {
      alert('السلة فارغة. لا يمكن إتمام الطلب.');
      return;
    }

    if (!currentUser) {
      alert('يجب تسجيل الدخول لإتمام الطلب');
      navigate('/auth');
      return;
    }

    setIsSubmitting(true);
    
    try {
      const orderId = generateOrderId();
      const orderTime = new Date().toLocaleString('ar-MA', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });

      const orderData = {
        id: orderId,
        user_id: currentUser.id, // إضافة معرف المستخدم
        restaurant: cartItems[0]?.restaurant || 'مطاعم متنوعة',
        items: cartItems.map(item => ({
          id: item.id,
          name: item.name,
          price: item.price,
          quantity: item.quantity,
          image: item.image
        })),
        total: total,
        status: 'confirmed',
        estimatedTime: '30-45 دقيقة',
        orderTime: orderTime,
        deliveryInfo,
        paymentMethod,
        subtotal,
        deliveryFee,
        discount,
        createdAt: new Date().toISOString(),
        estimatedDelivery: new Date(Date.now() + 45 * 60 * 1000).toISOString()
      };

      // محاكاة إرسال الطلب
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // حفظ الطلب في localStorage
      const existingOrders = JSON.parse(localStorage.getItem('orders') || '[]');
      existingOrders.push(orderData);
      localStorage.setItem('orders', JSON.stringify(existingOrders));
      localStorage.setItem('currentOrder', JSON.stringify(orderData));
      
      // تفريغ السلة فوراً بعد تأكيد الطلب
      localStorage.removeItem('cart');
      localStorage.removeItem('appliedPromo');
      setCartItems([]);
      
      // إرسال حدث مخصص لتحديث عداد السلة في الهيدر
      window.dispatchEvent(new CustomEvent('cartUpdated'));
      
      // محاكاة تحديث حالة الطلب إلى "preparing" بعد 30 ثانية
      setTimeout(() => {
        const updatedOrderData = { ...orderData, status: 'preparing' };
        const orders = JSON.parse(localStorage.getItem('orders') || '[]');
        const orderIndex = orders.findIndex((order: any) => order.id === orderId);
        if (orderIndex !== -1) {
          orders[orderIndex] = updatedOrderData;
          localStorage.setItem('orders', JSON.stringify(orders));
          localStorage.setItem('currentOrder', JSON.stringify(updatedOrderData));
        }
      }, 30000);
      
      // التوجه إلى صفحة تتبع الطلب
      navigate('/track-order', { state: { orderId } });
    } catch (error) {
      console.error('خطأ في إرسال الطلب:', error);
      alert('حدث خطأ في إرسال الطلب. يرجى المحاولة مرة أخرى.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // عرض شاشة التحميل
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <main className="max-w-4xl mx-auto px-4 py-8 pt-24">
          <div className="text-center py-16">
            <i className="ri-loader-4-line text-6xl text-orange-500 animate-spin mb-4"></i>
            <p className="text-gray-600">جاري تحميل بيانات السلة...</p>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  // التحقق من وجود عناصر في السلة بعد التحميل
  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <main className="max-w-4xl mx-auto px-4 py-8 pt-24">
          <div className="text-center py-16">
            <i className="ri-shopping-cart-line text-8xl text-gray-300 mb-6"></i>
            <h2 className="text-2xl font-bold text-gray-600 mb-4">السلة فارغة</h2>
            <p className="text-gray-500 mb-8">لا يمكن إتمام الطلب بدون منتجات في السلة</p>
            <div className="space-y-4">
              <button 
                onClick={() => navigate('/restaurants')}
                className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-lg font-medium transition-colors cursor-pointer whitespace-nowrap"
              >
                تصفح المطاعم
              </button>
              <br />
              <button 
                onClick={() => navigate('/cart')}
                className="text-orange-500 hover:text-orange-600 text-sm cursor-pointer"
              >
                العودة إلى السلة
              </button>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-6xl mx-auto px-4 py-8 pt-24">
        <div className="flex items-center gap-4 mb-8">
          <button 
            onClick={() => navigate('/cart')}
            className="text-gray-600 hover:text-orange-500 cursor-pointer"
          >
            <i className="ri-arrow-right-line text-xl"></i>
          </button>
          <h1 className="text-3xl font-bold text-gray-800">إتمام الطلب</h1>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* معلومات التوصيل */}
          <div className="lg:col-span-2 space-y-6">
            {/* معلومات العميل */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-6 flex items-center gap-2">
                <i className="ri-user-line text-orange-500 w-5 h-5 flex items-center justify-center"></i>
                معلومات التوصيل
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    الاسم الكامل *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={deliveryInfo.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    className={`w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm ${
                      errors.name ? 'border-red-500' : 'border-gray-300'
                    }`}
                    placeholder="أدخل اسمك الكامل"
                    required
                  />
                  {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    رقم الهاتف *
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={deliveryInfo.phone}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                    className={`w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm ${
                      errors.phone ? 'border-red-500' : 'border-gray-300'
                    }`}
                    placeholder="0612345678"
                    required
                  />
                  {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
                </div>
                
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    العنوان التفصيلي *
                  </label>
                  <input
                    type="text"
                    name="address"
                    value={deliveryInfo.address}
                    onChange={(e) => handleInputChange('address', e.target.value)}
                    className={`w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm ${
                      errors.address ? 'border-red-500' : 'border-gray-300'
                    }`}
                    placeholder="الشارع، الحي، رقم المنزل، نقاط مرجعية"
                    required
                  />
                  {errors.address && <p className="text-red-500 text-xs mt-1">{errors.address}</p>}
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    المدينة *
                  </label>
                  <select
                    name="city"
                    value={deliveryInfo.city}
                    onChange={(e) => handleInputChange('city', e.target.value)}
                    className={`w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm pr-8 ${
                      errors.city ? 'border-red-500' : 'border-gray-300'
                    }`}
                    required
                  >
                    <option value="">اختر المدينة</option>
                    <option value="الدار البيضاء">الدار البيضاء</option>
                    <option value="الرباط">الرباط</option>
                    <option value="فاس">فاس</option>
                    <option value="مراكش">مراكش</option>
                    <option value="طنجة">طنجة</option>
                    <option value="أكادير">أكادير</option>
                    <option value="مكناس">مكناس</option>
                    <option value="وجدة">وجدة</option>
                    <option value="القنيطرة">القنيطرة</option>
                    <option value="تطوان">تطوان</option>
                  </select>
                  {errors.city && <p className="text-red-500 text-xs mt-1">{errors.city}</p>}
                </div>
                
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    ملاحظات إضافية
                  </label>
                  <textarea
                    value={deliveryInfo.notes}
                    onChange={(e) => handleInputChange('notes', e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 text-sm"
                    rows={3}
                    maxLength={500}
                    placeholder="أي ملاحظات خاصة للتوصيل (اختياري)..."
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    {deliveryInfo.notes.length}/500 حرف
                  </p>
                </div>
              </div>
            </div>

            {/* طريقة الدفع */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-6 flex items-center gap-2">
                <i className="ri-bank-card-line text-orange-500 w-5 h-5 flex items-center justify-center"></i>
                طريقة الدفع
              </h2>
              
              <div className="space-y-4">
                <div 
                  className={`border-2 rounded-lg p-4 cursor-pointer transition-all hover:shadow-md ${
                    paymentMethod === 'cash' ? 'border-orange-500 bg-orange-50' : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setPaymentMethod('cash')}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                      paymentMethod === 'cash' ? 'border-orange-500' : 'border-gray-300'
                    }`}>
                      {paymentMethod === 'cash' && <div className="w-3 h-3 bg-orange-500 rounded-full"></div>}
                    </div>
                    <div className="w-8 h-8 flex items-center justify-center">
                      <i className="ri-money-dollar-circle-line text-xl text-gray-600"></i>
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-800">الدفع نقداً عند التوصيل</h3>
                      <p className="text-sm text-gray-600">ادفع للمندوب عند استلام الطلب</p>
                    </div>
                  </div>
                </div>
                
                <div 
                  className={`border-2 rounded-lg p-4 cursor-pointer transition-all hover:shadow-md ${
                    paymentMethod === 'card' ? 'border-orange-500 bg-orange-50' : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setPaymentMethod('card')}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                      paymentMethod === 'card' ? 'border-orange-500' : 'border-gray-300'
                    }`}>
                      {paymentMethod === 'card' && <div className="w-3 h-3 bg-orange-500 rounded-full"></div>}
                    </div>
                    <div className="w-8 h-8 flex items-center justify-center">
                      <i className="ri-bank-card-line text-xl text-gray-600"></i>
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-800">الدفع بالبطاقة البنكية</h3>
                      <p className="text-sm text-gray-600">دفع آمن عبر الإنترنت</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* ملخص الطلب */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm p-6 sticky top-24">
              <h2 className="text-xl font-bold text-gray-800 mb-6 flex items-center gap-2">
                <i className="ri-file-list-line text-orange-500 w-5 h-5 flex items-center justify-center"></i>
                ملخص الطلب
              </h2>
              
              {/* عناصر السلة */}
              <div className="space-y-4 mb-6 max-h-64 overflow-y-auto">
                {cartItems.map((item) => (
                  <div key={item.id} className="flex gap-3 p-2 rounded-lg hover:bg-gray-50">
                    <img 
                      src={item.image} 
                      alt={item.name}
                      className="w-12 h-12 object-cover object-top rounded-lg"
                    />
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-800 text-sm">{item.name}</h3>
                      <p className="text-xs text-gray-600">{item.restaurant}</p>
                      <div className="flex justify-between items-center mt-1">
                        <span className="text-xs text-gray-500">الكمية: {item.quantity}</span>
                        <span className="font-medium text-sm text-orange-600">{item.price * item.quantity} DH</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* تفاصيل السعر */}
              <div className="space-y-3 mb-6 border-t pt-4">
                <div className="flex justify-between">
                  <span className="text-gray-600">المجموع الفرعي</span>
                  <span className="font-medium">{subtotal.toFixed(2)} DH</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">رسوم التوصيل</span>
                  <span className="font-medium">{deliveryFee.toFixed(2)} DH</span>
                </div>
                {appliedPromo && (
                  <div className="flex justify-between text-green-600">
                    <span>الخصم ({appliedPromo.code})</span>
                    <span>-{discount.toFixed(2)} DH</span>
                  </div>
                )}
                <div className="border-t pt-3">
                  <div className="flex justify-between text-lg font-bold">
                    <span>المجموع الكلي</span>
                    <span className="text-orange-600">{total.toFixed(2)} DH</span>
                  </div>
                </div>
              </div>

              {/* زر إتمام الطلب */}
              <button 
                onClick={handleSubmitOrder}
                disabled={isSubmitting}
                className="w-full bg-orange-500 hover:bg-orange-600 disabled:bg-gray-400 disabled:cursor-not-allowed text-white py-3 rounded-lg font-medium transition-colors cursor-pointer whitespace-nowrap flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <i className="ri-loader-4-line animate-spin"></i>
                    جاري إرسال الطلب...
                  </>
                ) : (
                  <>
                    <i className="ri-check-line w-5 h-5 flex items-center justify-center"></i>
                    تأكيد الطلب ({total.toFixed(2)} DH)
                  </>
                )}
              </button>
              
              <div className="mt-4 text-center">
                <button 
                  onClick={() => navigate('/cart')}
                  className="text-orange-500 hover:text-orange-600 text-sm cursor-pointer"
                >
                  العودة إلى السلة
                </button>
              </div>

              {/* معلومات إضافية */}
              <div className="mt-6 pt-4 border-t">
                <div className="text-xs text-gray-500 space-y-2">
                  <div className="flex items-center gap-2">
                    <i className="ri-time-line text-orange-500 w-4 h-4 flex items-center justify-center"></i>
                    <span>وقت التوصيل المتوقع: 30-45 دقيقة</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <i className="ri-shield-check-line text-green-500 w-4 h-4 flex items-center justify-center"></i>
                    <span>دفع آمن ومضمون</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
