import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    )

    const url = new URL(req.url)
    const method = req.method

    if (method === 'GET') {
      // جلب التقييمات - لا يتطلب مصادقة
      const restaurantId = url.searchParams.get('restaurant_id')
      const productId = url.searchParams.get('product_id')

      let query = supabaseClient
        .from('ratings')
        .select('*')
        .order('created_at', { ascending: false })

      if (restaurantId) {
        query = query.eq('restaurant_id', restaurantId)
      } else if (productId) {
        query = query.eq('product_id', productId)
      }

      const { data: ratings, error } = await query

      if (error) {
        return new Response(
          JSON.stringify({ error: error.message }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      // جلب معلومات المستخدمين
      const userIds = [...new Set(ratings.map(r => r.user_id).filter(Boolean))]
      let usersMap: Record<string, any> = {}

      if (userIds.length > 0) {
        const { data: users } = await supabaseClient
          .from('users')
          .select('id, full_name')
          .in('id', userIds)

        if (users) {
          usersMap = users.reduce((acc, user) => {
            acc[user.id] = user
            return acc
          }, {} as Record<string, any>)
        }
      }

      // حساب متوسط التقييم
      const averageRating = ratings.length > 0 
        ? ratings.reduce((sum, rating) => sum + rating.rating, 0) / ratings.length
        : 0

      // تنسيق البيانات
      const formattedRatings = ratings.map(rating => ({
        id: rating.id,
        user_id: rating.user_id,
        rating: rating.rating,
        comment: rating.comment,
        created_at: rating.created_at,
        user_name: usersMap[rating.user_id]?.full_name || 'مستخدم'
      }))

      return new Response(
        JSON.stringify({
          ratings: formattedRatings,
          average_rating: averageRating,
          total_count: ratings.length
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // للعمليات الأخرى، نحتاج مصادقة
    const { data: { user } } = await supabaseClient.auth.getUser()
    if (!user) {
      return new Response(
        JSON.stringify({ error: 'غير مصرح' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    if (method === 'POST') {
      // إضافة تقييم جديد
      const { restaurant_id, product_id, rating, comment } = await req.json()

      if (!rating || rating < 1 || rating > 5) {
        return new Response(
          JSON.stringify({ error: 'التقييم يجب أن يكون بين 1 و 5' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      if (!restaurant_id && !product_id) {
        return new Response(
          JSON.stringify({ error: 'يجب تحديد المطعم أو المنتج' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      // التحقق من وجود تقييم سابق
      let existingQuery = supabaseClient
        .from('ratings')
        .select('id')
        .eq('user_id', user.id)

      if (restaurant_id) {
        existingQuery = existingQuery.eq('restaurant_id', restaurant_id)
      } else {
        existingQuery = existingQuery.eq('product_id', product_id)
      }

      const { data: existing } = await existingQuery.single()

      let result
      if (existing) {
        // تحديث التقييم الموجود
        const { data, error } = await supabaseClient
          .from('ratings')
          .update({
            rating,
            comment,
            updated_at: new Date().toISOString()
          })
          .eq('id', existing.id)
          .select()
          .single()

        result = { data, error }
      } else {
        // إضافة تقييم جديد
        const { data, error } = await supabaseClient
          .from('ratings')
          .insert({
            user_id: user.id,
            restaurant_id,
            product_id,
            rating,
            comment
          })
          .select()
          .single()

        result = { data, error }
      }

      if (result.error) {
        return new Response(
          JSON.stringify({ error: result.error.message }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      return new Response(
        JSON.stringify({ success: true, data: result.data }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    if (method === 'DELETE') {
      // حذف التقييم
      const ratingId = url.searchParams.get('id')

      if (!ratingId) {
        return new Response(
          JSON.stringify({ error: 'معرف التقييم مطلوب' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      const { error } = await supabaseClient
        .from('ratings')
        .delete()
        .eq('id', ratingId)
        .eq('user_id', user.id)

      if (error) {
        return new Response(
          JSON.stringify({ error: error.message }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      return new Response(
        JSON.stringify({ success: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    return new Response(
      JSON.stringify({ error: 'طريقة غير مدعومة' }),
      { status: 405, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})